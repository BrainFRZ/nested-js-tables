import React, { Component } from 'react';
// import ToolTip from 'mappletooltip';
// import PageWithToolTip from './PageWithToolTip';
import SampleMapple from './SampleMapple';

const App = () => {
  return (
    <div>
      <SampleMapple />
      {/* <PageWithToolTip /> */}
    </div>
  );
};

export default App;

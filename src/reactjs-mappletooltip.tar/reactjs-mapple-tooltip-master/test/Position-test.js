const assert = require('assert');

describe('Empty test', () => {
  it('empty test should run successfully', () => {
    assert.equal('A', 'A');
  });
});
